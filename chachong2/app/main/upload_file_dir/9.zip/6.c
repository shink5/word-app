#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Number:190210503\nSubject:No.2  -  Program:No.1\n");
    const double PI=3.14159;
    double r;
    printf("Input r:");
    scanf("%lf",&r);
    printf("area=%f\n",4*PI*r*r);
    printf("V=%f\n",PI*r*r*r*4/3);
}

